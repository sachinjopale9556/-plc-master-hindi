PLC Master Hindi – Offline Android learning starter project.
Includes Hindi PLC basics and a simple interactive AND ladder simulator.
Educational only; it does not connect to physical PLC hardware.
