# PLC Master Hindi V6

Independent offline Android PLC ladder learning/simulator project inspired by common mobile ladder-simulator workflows.

Features: visual ladder editor, NO/NC contacts, series/parallel branches, generic text logic compiler, basic input/output simulator, function-block placeholders for TON/TOF/CTU/CTD/SET/RESET/ANALOG, local project save/open, JSON import/export, basic educational Arduino sketch generation, brand reference labels for Delta/Siemens/Mitsubishi/Omron/Allen-Bradley/Schneider.

Important limitations: timer/counter/analog function blocks are currently educational placeholders and not fully IEC-compliant runtime implementations. Arduino output is a basic generated sketch requiring pin mapping review. No real PLC communication, vendor-native compilation, or PLC download. Test all generated code safely before hardware use.

Build: JDK 17, Android SDK platform 35, Gradle 8.9. GitHub workflow included.
