# PLC Master Hindi – Android project with cloud APK build

## Build APK using only an Android phone (GitHub Actions)

1. Download and extract this ZIP on your Android phone (My Files > Downloads > ZIP > Extract).
2. In Chrome, create/sign in to a GitHub account: https://github.com
3. On GitHub, tap **+** > **New repository**. Name it `plc-master-hindi`, choose **Public** or **Private**, then Create repository.
4. Open the new empty repository. Choose **Add file** > **Upload files**.
5. Upload the *contents* of the extracted `PLCMasterAndroid` folder (including `.github`, `app`, `build.gradle`, `settings.gradle`, and `gradle.properties`). Make sure `.github/workflows/android.yml` is included. If the phone file picker hides dot-folders, create `.github/workflows` and `android.yml` using GitHub's **Add file > Create new file** interface; enter `.github/workflows/android.yml` as the filename and paste the workflow from this project.
6. Tap **Commit changes**. The workflow runs automatically after the commit.
7. In the repository, open **Actions** > **Build PLC Master APK**. Wait until the run shows a green check mark.
8. Open the successful run, scroll to **Artifacts**, and download `PLC-Master-Hindi-debug-APK`.
9. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
10. Tap `app-debug.apk` in My Files. If Android asks, allow **Install unknown apps** for My Files/Chrome, then tap **Install**.

## Manual trigger
Repository > Actions > Build PLC Master APK > Run workflow.

## Notes
- This produces a debug APK for personal testing; it is not Play Store signed/release-ready.
- GitHub account and internet access are required for cloud building.
- The app itself has no Internet permission and its learning content/simulator work offline.
- Simulator is educational only and does not connect to physical PLC hardware.
