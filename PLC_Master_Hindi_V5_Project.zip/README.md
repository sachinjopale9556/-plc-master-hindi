# PLC Master Hindi V5
Offline Android app: visual ladder editor, text/code editor, generic ladder compiler, AND/OR simulator, NO/NC contacts, output coils, input toggles, offline local project save/open, JSON backup import/export, six PLC brand learning labels.
Generic simulator only. It does not connect to physical PLC hardware, compile vendor-native project files, or download code to PLCs. Vendor addressing differs by model.
Build requirements: JDK 17, Android SDK platform 35, Gradle 8.9.
